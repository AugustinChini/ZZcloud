A Pen created at CodePen.io. You can find this one at http://codepen.io/ionic/pen/cDbFg.

 Demo showing how to wire up a left side menu that stays exposed on large viewports.