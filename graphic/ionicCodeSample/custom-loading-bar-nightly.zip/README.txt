A Pen created at CodePen.io. You can find this one at http://codepen.io/ionic/pen/pEter.

 Example of custom Ionic loading indicator styled as a header bar.