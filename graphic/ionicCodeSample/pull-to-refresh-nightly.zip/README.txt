A Pen created at CodePen.io. You can find this one at http://codepen.io/ionic/pen/mqolp.

 Example using ion-refresher for the "pull to refresh" effect